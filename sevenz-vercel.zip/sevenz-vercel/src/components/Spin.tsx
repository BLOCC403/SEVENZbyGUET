export function Spin({ s = 20 }: { s?: number }) {
  return (
    <div
      style={{
        width: s, height: s, borderRadius: "50%",
        border: "2px solid rgba(255,255,255,0.1)",
        borderTopColor: "#4f6ef7",
        display: "inline-block",
        animation: "spinAnim 0.75s linear infinite",
      }}
    />
  );
}
