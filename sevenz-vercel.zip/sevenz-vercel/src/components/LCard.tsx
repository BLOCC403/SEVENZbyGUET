import { Lawyer } from "@/data/lawyers";

interface LCardProps {
  l: Lawyer;
  isFav: boolean;
  onFav: (id: number) => void;
  delay?: number;
}

export function Stars({ r }: { r: number }) {
  return (
    <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
      <span style={{ color: "#D4AF37", fontSize: 11, letterSpacing: 1.5 }}>
        {"★".repeat(Math.floor(r))}{"☆".repeat(5 - Math.floor(r))}
      </span>
      <span style={{ color: "#5a5040", fontSize: 11, fontWeight: 700 }}>{r.toFixed(1)}</span>
    </span>
  );
}

const fmtPhone = (p: string) => {
  const d = p.replace(/\D/g, "");
  if (d.length === 11) return `(${d.slice(0,2)}) ${d.slice(2,3)} ${d.slice(3,7)}-${d.slice(7)}`;
  return p;
};

export function LCard({ l, isFav, onFav, delay = 0 }: LCardProps) {
  const waLink = `https://wa.me/55${l.phone.replace(/\D/g, "")}`;

  return (
    <div
      className="lawyer-card fade-up"
      style={{ animationDelay: `${delay}ms` }}
      data-testid={`card-lawyer-${l.id}`}
    >
      {/* Header */}
      <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
        <div className="av">{l.avatar}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{
                fontFamily: "'Bricolage Grotesque', sans-serif",
                fontWeight: 800, fontSize: 15, color: "#f0e8d0",
                whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                lineHeight: 1.2, marginBottom: 2,
              }}>
                {l.name}
              </div>
              <div style={{ fontSize: 10.5, color: "#5a5040", fontWeight: 600, letterSpacing: 0.3 }}>
                {l.oab}
              </div>
            </div>
            <button className="fav-btn" onClick={() => onFav(l.id)} data-testid={`btn-fav-${l.id}`}>
              {isFav ? "❤️" : "🤍"}
            </button>
          </div>
        </div>
      </div>

      {/* Info row */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 12 }}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
          <span className="badge b-gold">{l.specialty}</span>
          <span className="badge b-gray">📍 {l.city} · {l.state}</span>
        </div>
        <Stars r={l.rating} />
      </div>

      {/* Stats strip */}
      <div style={{
        display: "flex", gap: 12, marginTop: 11, padding: "9px 12px",
        background: "rgba(212,175,55,0.04)", borderRadius: 12,
        border: "1px solid rgba(212,175,55,0.08)",
      }}>
        <div style={{ textAlign: "center", flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 800, color: "#D4AF37", fontFamily: "'Bricolage Grotesque', sans-serif" }}>{l.exp}a</div>
          <div style={{ fontSize: 9, color: "#5a5040", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.8 }}>Exp</div>
        </div>
        <div style={{ width: 1, background: "rgba(212,175,55,0.1)" }} />
        <div style={{ flex: 2, display: "flex", alignItems: "center", gap: 7 }}>
          <span style={{ fontSize: 12.5, color: "#b8a878", fontWeight: 600 }}>📞 {fmtPhone(l.phone)}</span>
        </div>
        {l.aiGenerated && (
          <>
            <div style={{ width: 1, background: "rgba(212,175,55,0.1)" }} />
            <span className="badge b-purple" style={{ alignSelf: "center" }}>✨ IA</span>
          </>
        )}
      </div>

      {/* Action buttons */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 8, marginTop: 11 }}>
        <a href={waLink} target="_blank" rel="noopener noreferrer" style={{ textDecoration: "none" }}>
          <button className="btn btn-wa" data-testid={`btn-whatsapp-${l.id}`} style={{ width: "100%" }}>
            💬 WhatsApp
          </button>
        </a>
        <a href={`mailto:${l.email}`} style={{ textDecoration: "none" }}>
          <button className="btn btn-g" data-testid={`btn-email-${l.id}`} style={{ fontSize: 12 }}>
            ✉️ Email
          </button>
        </a>
      </div>
    </div>
  );
}
