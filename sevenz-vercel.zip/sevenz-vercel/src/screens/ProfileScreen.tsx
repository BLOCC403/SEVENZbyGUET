import { User, getPayments, getFavs } from "@/lib/storage";

interface Props {
  user: User;
  onLogout: () => void;
}

export function ProfileScreen({ user, onLogout }: Props) {
  const myPay = getPayments().find(p => p.userId === user.id);
  const favCnt = getFavs(user.id).length;

  const av = user.name
    ?.split(" ")
    .filter(w => w.length > 2 && /[A-ZÁÉÍÓÚÂÊÎÔÛÃÕ]/i.test(w[0]))
    .slice(0, 2)
    .map(w => w[0])
    .join("") || "U";

  const StatusBadge = ({ s }: { s: string }) => {
    if (s === "paid") return <span className="badge b-green">✓ Acesso ativo</span>;
    if (s === "pending_confirmation") return <span className="badge b-yellow">⏳ Aguardando confirmação</span>;
    return <span className="badge b-red">⚠ Pagamento pendente</span>;
  };

  return (
    <div style={{ paddingTop: 72, paddingBottom: 92, minHeight: "100vh", position: "relative", zIndex: 1 }}>
      <div style={{ padding: "22px 16px 0" }}>
        <div className="h1">Meu <span className="g-text">perfil</span></div>
      </div>

      <div style={{ padding: "14px 16px" }}>
        <div className="glass" style={{ borderRadius: 22, padding: 24, marginBottom: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div
              className="av"
              style={{ width: 60, height: 60, fontSize: 20, borderRadius: "50%", animation: "pulseRing 2.8s ease infinite" }}
            >
              {av}
            </div>
            <div>
              <div className="h2" style={{ color: "var(--text)", fontSize: 18 }}>{user.name}</div>
              <div style={{ fontSize: 13, color: "var(--text3)", marginTop: 3 }}>{user.email}</div>
              {user.role === "admin" && (
                <span className="badge b-red" style={{ marginTop: 7, display: "inline-flex" }}>ADMIN</span>
              )}
            </div>
          </div>

          <div style={{ height: 1, background: "linear-gradient(90deg, transparent, var(--border2), transparent)", margin: "16px 0" }} />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div style={{ background: "var(--surface)", borderRadius: 14, padding: 16, textAlign: "center", border: "1px solid var(--border)" }}>
              <div style={{ fontSize: 28, fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 800, color: "#d946ef" }}>{favCnt}</div>
              <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 3 }}>Favoritos</div>
            </div>
            <div style={{ background: "var(--surface)", borderRadius: 14, padding: 16, textAlign: "center", border: "1px solid var(--border)" }}>
              <div style={{ fontSize: 28, fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 800, color: "#4ade80" }}>
                {myPay?.status === "paid" ? "✓" : "—"}
              </div>
              <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 3 }}>Acesso</div>
            </div>
          </div>
        </div>

        {myPay && (
          <div className="glass" style={{ borderRadius: 18, padding: 18, marginBottom: 14 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "var(--text)", marginBottom: 12 }}>💳 Pagamento</div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <StatusBadge s={myPay.status} />
              <span className="g-text" style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 800, fontSize: 18 }}>R${myPay.amount}</span>
            </div>
            {myPay.paidAt && (
              <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 8 }}>
                Pago em {new Date(myPay.paidAt).toLocaleDateString("pt-BR")}
              </div>
            )}
          </div>
        )}

        <div className="glass" style={{ borderRadius: 18, padding: 18, marginBottom: 14 }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: "var(--text)", marginBottom: 12 }}>ℹ️ Sobre a plataforma</div>
          <div style={{ fontSize: 12.5, color: "var(--text2)", lineHeight: 1.7 }}>
            SEVENZ é a maior rede de correspondentes jurídicos do Brasil. Conectamos escritórios de advocacia com profissionais qualificados em todo o território nacional.
          </div>
          <div style={{ marginTop: 12, fontSize: 10, color: "var(--text3)", fontWeight: 500 }}>
            Dados de <a href="https://correspondentesnaweb.com.br" target="_blank" rel="noopener noreferrer" style={{ color: "var(--text3)" }}>correspondentesnaweb.com.br</a>
          </div>
        </div>

        <button
          onClick={onLogout}
          data-testid="btn-logout"
          style={{ width: "100%", background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.22)", borderRadius: 16, padding: "14px 20px", cursor: "pointer", color: "#f87171", fontFamily: "inherit", fontWeight: 700, fontSize: 14, transition: "all 0.2s" }}
        >
          🚪 Sair da conta
        </button>
      </div>

      <div style={{ textAlign: "center", padding: "18px 0 6px", opacity: 0.5 }}>
        <span className="gueto">By GUETO™</span>
      </div>
    </div>
  );
}
