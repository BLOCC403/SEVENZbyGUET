import { useState } from "react";
import QRCode from "react-qr-code";
import { User, getPayments, savePayments } from "@/lib/storage";
import { PRICE, LAWYERS_DB, DDD_MAP } from "@/data/lawyers";
import { Spin } from "@/components/Spin";

interface Props {
  user: User;
  onPaid: () => void;
}

export function PaymentScreen({ user, onPaid }: Props) {
  const myPay = getPayments().find(p => p.userId === user.id);
  const [status, setStatus] = useState(myPay?.status || "pending");
  const [ld, setLd] = useState(false);
  const [copied, setCopied] = useState(false);

  const pixKey = "+5511958396402";
  const pixDisplay = "(11) 95839-6402";

  const upd = (s: "pending" | "pending_confirmation" | "paid") => {
    const all = getPayments();
    savePayments(all.map(p => p.userId === user.id ? { ...p, status: s, paidAt: new Date().toISOString() } : p));
    setStatus(s);
  };

  const onPaid2 = async () => {
    setLd(true);
    await new Promise(r => setTimeout(r, 600));
    upd("pending_confirmation");
    setLd(false);
  };

  const copy = () => {
    navigator.clipboard?.writeText(pixKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  if (status === "paid") return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, position: "relative", zIndex: 1 }}>
      <div className="glass fade-up" style={{ borderRadius: 28, padding: 44, textAlign: "center", maxWidth: 380, width: "100%" }}>
        <div style={{ fontSize: 72, marginBottom: 20 }}>🎉</div>
        <div className="h1" style={{ color: "#4ade80" }}>Acesso liberado!</div>
        <p style={{ color: "var(--text3)", fontSize: 14, marginTop: 10 }}>Carregando sua conta…</p>
        <div style={{ marginTop: 24 }}><Spin s={28} /></div>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "center", padding: "32px 20px", position: "relative", zIndex: 1 }}>
      <div style={{ maxWidth: 420, margin: "0 auto", width: "100%" }}>

        <div style={{ textAlign: "center", marginBottom: 28 }} className="fade-up">
          <div className="h1">Ativar <span className="g-text">acesso</span></div>
          <div style={{ fontSize: 13, color: "var(--text3)", marginTop: 6 }}>Pagamento único · sem mensalidade · acesso vitalício</div>
        </div>

        <div className="glass fade-up" style={{ borderRadius: 24, padding: 24, animationDelay: "60ms" }}>

          <div style={{ textAlign: "center", marginBottom: 20 }}>
            <div style={{ fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 900, fontSize: 56, lineHeight: 1 }}>
              <span className="g-text">R$ {PRICE}</span>
            </div>
            <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 4, fontWeight: 700, letterSpacing: 1.5 }}>
              PAGAMENTO ÚNICO · SEM MENSALIDADE
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginBottom: 20 }}>
            <div style={{ background: "#fff", borderRadius: 16, padding: 16, display: "inline-flex", flexDirection: "column", alignItems: "center", gap: 12, boxShadow: "0 8px 32px rgba(0,0,0,0.4)" }}>
              <QRCode
                value={pixKey}
                size={160}
                style={{ display: "block" }}
                fgColor="#07080f"
                bgColor="#ffffff"
                level="M"
              />
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <div style={{ width: 18, height: 18, borderRadius: 4, background: "linear-gradient(135deg, #00b1ea, #009ee3)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ color: "#fff", fontSize: 9, fontWeight: 900, fontFamily: "sans-serif" }}>MP</span>
                </div>
                <span style={{ fontSize: 10, color: "#555", fontWeight: 700, fontFamily: "sans-serif" }}>Mercado Pago</span>
              </div>
            </div>
            <div style={{ marginTop: 10, fontSize: 12, color: "var(--text3)", textAlign: "center" }}>
              Escaneie o QR Code com seu app de banco
            </div>
          </div>

          <div style={{ background: "rgba(79,110,247,0.08)", borderRadius: 13, padding: "13px 15px", display: "flex", justifyContent: "space-between", alignItems: "center", border: "1px solid rgba(79,110,247,0.18)", marginBottom: 16 }}>
            <div>
              <div className="label" style={{ marginBottom: 2 }}>Chave PIX • Celular</div>
              <div style={{ fontSize: 15, color: "#7b97fa", fontWeight: 800, letterSpacing: 0.3 }}>{pixDisplay}</div>
              <div style={{ fontSize: 10, color: "var(--text3)", marginTop: 2 }}>Mercado Pago</div>
            </div>
            <button
              onClick={copy}
              data-testid="btn-copy-pix"
              style={{
                background: copied ? "rgba(34,197,94,0.2)" : "rgba(79,110,247,0.2)",
                border: "none", borderRadius: 9, padding: "8px 14px",
                cursor: "pointer", color: copied ? "#4ade80" : "#7b97fa",
                fontSize: 12, fontWeight: 700, fontFamily: "inherit", transition: "all 0.2s",
                whiteSpace: "nowrap",
              }}
            >
              {copied ? "✓ Copiado" : "Copiar"}
            </button>
          </div>

          {status === "pending_confirmation" && (
            <div style={{ marginBottom: 14 }}>
              <div className="alert a-info">
                <span style={{ fontSize: 16, flexShrink: 0 }}>ℹ️</span>
                <span>Pagamento em análise. Confirmaremos em até 24h após verificação manual.</span>
              </div>
            </div>
          )}

          {status === "pending" && (
            <button className="btn btn-p" onClick={onPaid2} disabled={ld} data-testid="btn-paid-pix">
              {ld ? <Spin /> : "✅ Já efetuei o pagamento"}
            </button>
          )}

          {status === "pending_confirmation" && (
            <div style={{ textAlign: "center", padding: "10px 0 0", fontSize: 12, color: "var(--text3)" }}>
              Aguardando confirmação do pagamento…
            </div>
          )}
        </div>

        <div style={{ marginTop: 14, background: "rgba(79,110,247,0.06)", border: "1px solid rgba(79,110,247,0.15)", borderRadius: 16, padding: 16 }}>
          <div style={{ fontSize: 12, color: "#7b97fa", fontWeight: 700, marginBottom: 10 }}>✨ O que você terá acesso:</div>
          {[
            `+${LAWYERS_DB.length} advogados em todo Brasil`,
            `${Object.keys(DDD_MAP).length} DDDs cobertos`,
            "Filtro IA com Claude",
            "Contato direto via WhatsApp",
            "Acesso vitalício sem renovação",
          ].map(t => (
            <div key={t} style={{ fontSize: 12.5, color: "var(--text2)", padding: "4px 0", display: "flex", gap: 7 }}>
              <span style={{ color: "#4ade80" }}>✓</span> {t}
            </div>
          ))}
        </div>

        <div style={{ textAlign: "center", padding: "18px 0 6px", opacity: 0.5 }}>
          <span className="gueto">By GUETO™</span>
        </div>
      </div>
    </div>
  );
}
