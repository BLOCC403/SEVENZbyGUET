import { useState } from "react";
import { getUsers, getPayments, savePayments } from "@/lib/storage";
import { LAWYERS_DB, DDD_MAP, PRICE } from "@/data/lawyers";

export function AdminScreen() {
  const [users, setUsers] = useState(() => getUsers());
  const [pays, setPays] = useState(() => getPayments());
  const [tab, setTab] = useState("overview");
  const [msg, setMsg] = useState("");

  const paid = pays.filter(p => p.status === "paid");
  const pending = pays.filter(p => p.status !== "paid");

  const approve = (id: string) => {
    const u = pays.map(p => p.id === id ? { ...p, status: "paid" as const, paidAt: new Date().toISOString() } : p);
    savePayments(u); setPays(u);
    setMsg("Pagamento aprovado!");
    setTimeout(() => setMsg(""), 3000);
  };

  const StatusBadge = ({ s }: { s: string }) => {
    if (s === "paid") return <span className="badge b-green">✓ Pago</span>;
    if (s === "pending_confirmation") return <span className="badge b-yellow">⏳ Análise</span>;
    return <span className="badge b-red">⚠ Pendente</span>;
  };

  const adminTabs = [
    ["overview", "📊", "Visão"],
    ["users", "👥", "Usuários"],
    ["payments", "💳", "Pgtos"],
    ["db", "⚖️", "Banco"],
  ];

  return (
    <div style={{ paddingTop: 72, paddingBottom: 92, minHeight: "100vh", position: "relative", zIndex: 1 }}>
      <div style={{ padding: "22px 16px 0" }}>
        <div className="label">Sistema</div>
        <div className="h1">Painel <span className="g-text">Admin</span></div>
      </div>

      {msg && (
        <div style={{ padding: "10px 16px 0" }}>
          <div className="alert a-ok"><span style={{ fontSize: 16 }}>✅</span><span>{msg}</span></div>
        </div>
      )}

      <div style={{ display: "flex", gap: 6, padding: "14px 16px 0", overflowX: "auto", scrollbarWidth: "none" }}>
        {adminTabs.map(([t, ic, l]) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            data-testid={`tab-admin-${t}`}
            style={{
              background: tab === t ? "var(--grad)" : "var(--surface)",
              border: "1px solid",
              borderColor: tab === t ? "transparent" : "var(--border)",
              borderRadius: 13, padding: "9px 15px", cursor: "pointer",
              color: tab === t ? "#fff" : "var(--text2)",
              fontSize: 12, fontWeight: 700, fontFamily: "inherit", whiteSpace: "nowrap",
              transition: "all 0.2s",
              boxShadow: tab === t ? "0 4px 20px rgba(79,110,247,0.3)" : "none",
            }}
          >
            {ic} {l}
          </button>
        ))}
      </div>

      <div style={{ padding: "14px 16px" }}>
        {tab === "overview" && (
          <div className="fade-in">
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
              {([["Usuários", users.length, "#7b97fa"], ["Pagos", paid.length, "#4ade80"], ["Pendentes", pending.length, "#fbbf24"], ["Receita", `R$${paid.length * PRICE}`, "#a78bfa"]] as [string, string|number, string][]).map(([l, v, c]) => (
                <div key={l} className="stat">
                  <div className="stat-n" style={{ color: c }}>{v}</div>
                  <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 5 }}>{l}</div>
                </div>
              ))}
            </div>
            <div className="glass" style={{ borderRadius: 18, padding: 18 }}>
              <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 16, color: "var(--text)" }}>📈 Status dos pagamentos</div>
              {([["Pagos", paid.length, "#4ade80"], ["Em análise", pays.filter(p => p.status === "pending_confirmation").length, "#fbbf24"], ["Pendentes", pays.filter(p => p.status === "pending").length, "#f87171"]] as [string, number, string][]).map(([l, v, c]) => (
                <div key={l} style={{ marginBottom: 13 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 6 }}>
                    <span style={{ color: "var(--text2)" }}>{l}</span>
                    <span style={{ color: c, fontWeight: 700 }}>{v}</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width: `${pays.length ? (v / pays.length) * 100 : 0}%`, background: c }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "users" && (
          <div className="fade-in glass" style={{ borderRadius: 18, overflow: "hidden" }}>
            <div style={{ overflowX: "auto", WebkitOverflowScrolling: "touch" }}>
              {users.length === 0 ? (
                <div style={{ textAlign: "center", padding: 32, color: "var(--text3)" }}>Nenhum usuário cadastrado</div>
              ) : (
                <table>
                  <thead>
                    <tr>
                      <th>Nome</th>
                      <th>Email</th>
                      <th>Data</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u.id}>
                        <td style={{ color: "var(--text)", fontWeight: 600 }}>{u.name}</td>
                        <td>{u.email}</td>
                        <td style={{ color: "var(--text3)", fontSize: 10 }}>{new Date(u.createdAt).toLocaleDateString("pt-BR")}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        )}

        {tab === "payments" && (
          <div className="fade-in">
            {pays.length === 0 ? (
              <div className="glass" style={{ borderRadius: 18, textAlign: "center", padding: 32, color: "var(--text3)" }}>Nenhum pagamento registrado</div>
            ) : pays.map(p => (
              <div key={p.id} className="lawyer-card" style={{ padding: 16, marginBottom: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <div style={{ fontWeight: 700, color: "var(--text)", fontSize: 14 }}>{p.userName}</div>
                    <div style={{ fontSize: 11, color: "var(--text3)" }}>{p.userEmail}</div>
                    <div style={{ marginTop: 6 }}><StatusBadge s={p.status} /></div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div className="h2"><span className="g-text">R${p.amount}</span></div>
                    <div style={{ fontSize: 10, color: "var(--text3)" }}>{new Date(p.createdAt).toLocaleDateString("pt-BR")}</div>
                  </div>
                </div>
                {p.status !== "paid" && (
                  <button
                    onClick={() => approve(p.id)}
                    data-testid={`btn-approve-${p.id}`}
                    style={{ marginTop: 12, width: "100%", background: "linear-gradient(135deg,#f59e0b,#ef4444)", border: "none", borderRadius: 13, padding: "10px 16px", cursor: "pointer", color: "#fff", fontWeight: 700, fontFamily: "inherit", fontSize: 13 }}
                  >
                    ✅ Aprovar pagamento
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {tab === "db" && (
          <div className="fade-in">
            <div style={{ background: "rgba(79,110,247,0.08)", border: "1px solid rgba(79,110,247,0.18)", borderRadius: 15, padding: 16, marginBottom: 14 }}>
              <div style={{ fontSize: 13, color: "#7b97fa", fontWeight: 700 }}>📊 Estatísticas do banco</div>
              <div style={{ display: "flex", gap: 12, marginTop: 10, flexWrap: "wrap" }}>
                <span className="badge b-blue">{LAWYERS_DB.length} advogados</span>
                <span className="badge b-purple">{[...new Set(LAWYERS_DB.map(l => l.ddd))].length} DDDs</span>
                <span className="badge b-green">{[...new Set(LAWYERS_DB.map(l => l.state))].length} estados</span>
              </div>
              <div style={{ marginTop: 10, fontSize: 10, color: "var(--text3)", fontWeight: 500 }}>
                Fonte: <a href="https://correspondentesnaweb.com.br" target="_blank" rel="noopener noreferrer" style={{ color: "var(--text3)" }}>correspondentesnaweb.com.br</a>
              </div>
            </div>
            {[...new Set(LAWYERS_DB.map(l => l.ddd))].sort((a, b) => Number(a) - Number(b)).map(d => {
              const cnt = LAWYERS_DB.filter(l => l.ddd === d).length;
              return (
                <div key={d} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 14px", background: "var(--surface)", borderRadius: 12, marginBottom: 6, border: "1px solid var(--border)" }}>
                  <span style={{ fontWeight: 800, color: "#7b97fa", fontSize: 13, fontFamily: "'Bricolage Grotesque', sans-serif", minWidth: 36 }}>{d}</span>
                  <span style={{ fontSize: 12, color: "var(--text2)", flex: 1, marginLeft: 10 }}>{DDD_MAP[d] || d}</span>
                  <span className="badge b-blue">{cnt} advs</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
      <div style={{ textAlign: "center", padding: "18px 0 6px", opacity: 0.5 }}>
        <span className="gueto">By GUETO™</span>
      </div>
    </div>
  );
}
