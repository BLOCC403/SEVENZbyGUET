import { useState } from "react";
import { User, getUsers, saveUsers, getPayments, savePayments } from "@/lib/storage";
import { PRICE } from "@/data/lawyers";
import { Spin } from "@/components/Spin";

interface Props {
  onReg: (user: User) => void;
  onGoLogin: () => void;
}

export function RegisterScreen({ onReg, onGoLogin }: Props) {
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [ld, setLd] = useState(false);

  const go = async () => {
    setErr("");
    if (!f.name || !f.email || !f.password) { setErr("Preencha todos os campos."); return; }
    if (f.password.length < 6) { setErr("Senha mínima: 6 caracteres."); return; }
    const us = getUsers();
    if (us.find(u => u.email === f.email)) { setErr("Email já cadastrado."); return; }
    setLd(true);
    await new Promise(r => setTimeout(r, 700));
    const u: User = { id: Date.now().toString(), ...f, role: "user", createdAt: new Date().toISOString() };
    saveUsers([...us, u]);
    savePayments([...getPayments(), { id: Date.now().toString(), userId: u.id, userName: u.name, userEmail: u.email, status: "pending", amount: PRICE, createdAt: new Date().toISOString() }]);
    setLd(false);
    onReg(u);
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "center", padding: "32px 20px", position: "relative", zIndex: 1 }}>
      <div style={{ maxWidth: 400, margin: "0 auto", width: "100%" }}>
        <div style={{ textAlign: "center", marginBottom: 36 }} className="fade-up">
          <div className="h1"><span className="g-text">Criar conta</span></div>
          <div style={{ fontSize: 14, color: "var(--text3)", marginTop: 8 }}>Junte-se à maior rede jurídica do Brasil</div>
        </div>

        <div className="glass fade-up" style={{ borderRadius: 24, padding: 28, animationDelay: "60ms" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {[
              ["name", "Nome completo", "text"],
              ["email", "Email", "email"],
              ["password", "Senha (mín. 6 chars)", "password"],
            ].map(([k, ph, t]) => (
              <div key={k}>
                <div className="label">{ph}</div>
                <input
                  className="inp"
                  placeholder={ph}
                  type={t}
                  value={f[k as keyof typeof f]}
                  onChange={e => setF({ ...f, [k]: e.target.value })}
                  onKeyDown={e => e.key === "Enter" && go()}
                  data-testid={`input-register-${k}`}
                />
              </div>
            ))}
            {err && (
              <div className="alert a-err">
                <span style={{ fontSize: 16, flexShrink: 0 }}>⚠️</span>
                <span>{err}</span>
              </div>
            )}
            <button className="btn btn-p" onClick={go} disabled={ld} style={{ marginTop: 6 }} data-testid="btn-register">
              {ld ? <Spin /> : "Criar conta →"}
            </button>
          </div>
        </div>

        <div style={{ textAlign: "center", marginTop: 20, fontSize: 14 }}>
          <span style={{ color: "var(--text3)" }}>Já tem conta? </span>
          <button onClick={onGoLogin} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 14, fontWeight: 700 }} data-testid="btn-go-login">
            <span className="g-text">Entrar</span>
          </button>
        </div>
        <div style={{ textAlign: "center", padding: "18px 0 6px", opacity: 0.5 }}>
          <span className="gueto">By GUETO™</span>
        </div>
      </div>
    </div>
  );
}
