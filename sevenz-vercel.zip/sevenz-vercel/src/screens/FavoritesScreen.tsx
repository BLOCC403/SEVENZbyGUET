import { useState } from "react";
import { User, getFavs, saveFavs } from "@/lib/storage";
import { LAWYERS_DB } from "@/data/lawyers";
import { LCard } from "@/components/LCard";

interface Props {
  user: User;
}

export function FavoritesScreen({ user }: Props) {
  const [favs, setFavs] = useState(() => getFavs(user.id));
  const fl = LAWYERS_DB.filter(l => favs.includes(l.id));

  const toggle = (id: number) => {
    const n = favs.filter(f => f !== id);
    setFavs(n); saveFavs(user.id, n);
  };

  return (
    <div style={{ paddingTop: 72, paddingBottom: 92, minHeight: "100vh", position: "relative", zIndex: 1 }}>
      <div style={{ padding: "22px 16px 0 16px" }}>
        <div className="h1">Meus <span className="g-text">favoritos</span></div>
        <div style={{ fontSize: 13, color: "var(--text2)", marginTop: 5 }}>
          {fl.length} profissional{fl.length !== 1 ? "is" : ""} salvo{fl.length !== 1 ? "s" : ""}
        </div>
      </div>
      <div style={{ padding: "14px 16px 0" }}>
        {fl.length === 0 ? (
          <div style={{ textAlign: "center", padding: "72px 20px" }}>
            <div style={{ fontSize: 64 }}>🤍</div>
            <div className="h2" style={{ marginTop: 16, color: "var(--text2)" }}>Nenhum favorito ainda</div>
            <div style={{ fontSize: 13, marginTop: 8, color: "var(--text3)" }}>Toque no ❤️ nos cards para salvar advogados</div>
          </div>
        ) : fl.map((l, i) => (
          <LCard key={l.id} l={l} isFav={true} onFav={toggle} delay={i * 45} />
        ))}
      </div>
      <div style={{ textAlign: "center", padding: "18px 0 6px", opacity: 0.5 }}>
        <span className="gueto">By GUETO™</span>
      </div>
    </div>
  );
}
