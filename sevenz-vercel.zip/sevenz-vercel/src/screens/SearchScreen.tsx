import { useState, useMemo } from "react";
import { User, getFavs, saveFavs } from "@/lib/storage";
import { LAWYERS_DB, DDD_MAP, SPECIALTIES, Lawyer } from "@/data/lawyers";
import { LCard } from "@/components/LCard";
import { Spin } from "@/components/Spin";

const PAGE_SIZE = 10;
const QUICK_DDDS = ["11","21","31","41","51","61","71","81","85","62","91","92","47","48","98","27","83","84"];

type SortKey = "rating" | "exp" | "name";

function Skel() {
  return (
    <div className="lawyer-card" style={{ padding: 18, marginBottom: 10 }}>
      <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
        <div className="shimmer" style={{ width: 46, height: 46, borderRadius: 14, flexShrink: 0 }} />
        <div style={{ flex: 1 }}>
          <div className="shimmer" style={{ height: 15, width: "60%", marginBottom: 8, borderRadius: 6 }} />
          <div className="shimmer" style={{ height: 10, width: "30%", borderRadius: 6 }} />
        </div>
      </div>
      <div className="shimmer" style={{ height: 42, marginTop: 12, borderRadius: 12 }} />
      <div className="shimmer" style={{ height: 44, marginTop: 10, borderRadius: 13 }} />
    </div>
  );
}

function Pagination({ page, total, onChange }: { page: number; total: number; onChange: (p: number) => void }) {
  const totalPages = Math.ceil(total / PAGE_SIZE);
  if (totalPages <= 1) return null;

  const getPages = (): (number | "...")[] => {
    if (totalPages <= 7) return Array.from({ length: totalPages }, (_, i) => i + 1);
    const pages: (number | "...")[] = [1];
    if (page > 3) pages.push("...");
    for (let i = Math.max(2, page - 1); i <= Math.min(totalPages - 1, page + 1); i++) pages.push(i);
    if (page < totalPages - 2) pages.push("...");
    pages.push(totalPages);
    return pages;
  };

  const btnBase: React.CSSProperties = {
    border: "1px solid rgba(212,175,55,0.15)", borderRadius: 10,
    padding: "8px 12px", cursor: "pointer", fontFamily: "inherit",
    fontWeight: 700, fontSize: 13, transition: "all 0.15s", minWidth: 38,
  };

  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 5, padding: "14px 0 6px", flexWrap: "wrap" }}>
      <button onClick={() => onChange(page - 1)} disabled={page === 1}
        style={{ ...btnBase, background: "rgba(255,255,255,0.03)", color: page === 1 ? "#333" : "#b8a878", cursor: page === 1 ? "not-allowed" : "pointer" }}>‹</button>
      {getPages().map((p, i) =>
        p === "..." ? (
          <span key={`d${i}`} style={{ color: "#333", padding: "0 2px", fontSize: 13 }}>…</span>
        ) : (
          <button key={p} onClick={() => onChange(p as number)} style={{
            ...btnBase,
            background: page === p ? "linear-gradient(135deg, #D4AF37, #a07c10)" : "rgba(255,255,255,0.03)",
            color: page === p ? "#080808" : "#b8a878",
            border: page === p ? "none" : "1px solid rgba(212,175,55,0.15)",
            boxShadow: page === p ? "0 4px 14px rgba(212,175,55,0.3)" : "none",
          }}>{p}</button>
        )
      )}
      <button onClick={() => onChange(page + 1)} disabled={page === Math.ceil(total / PAGE_SIZE)}
        style={{ ...btnBase, background: "rgba(255,255,255,0.03)", color: page === Math.ceil(total / PAGE_SIZE) ? "#333" : "#b8a878", cursor: page === Math.ceil(total / PAGE_SIZE) ? "not-allowed" : "pointer" }}>›</button>
    </div>
  );
}

interface Props { user: User; }

export function SearchScreen({ user }: Props) {
  const [ddd, setDdd] = useState("");
  const [spec, setSpec] = useState("");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<SortKey>("rating");
  const [minExp, setMinExp] = useState(0);
  const [minRating, setMinRating] = useState(0);
  const [showFilters, setShowFilters] = useState(false);
  const [aiMode, setAiMode] = useState(false);
  const [aiRes, setAiRes] = useState<Lawyer[]>([]);
  const [aiLd, setAiLd] = useState(false);
  const [aiErr, setAiErr] = useState("");
  const [favs, setFavs] = useState(() => getFavs(user.id));
  const [page, setPage] = useState(1);

  const resetPage = () => setPage(1);

  const toggleFav = (id: number) => {
    const n = favs.includes(id) ? favs.filter(f => f !== id) : [...favs, id];
    setFavs(n); saveFavs(user.id, n);
  };

  const filtered = useMemo(() => {
    let list = LAWYERS_DB.filter(l => {
      if (ddd && l.ddd !== ddd) return false;
      if (spec && l.specialty !== spec && l.type !== spec) return false;
      if (minExp > 0 && l.exp < minExp) return false;
      if (minRating > 0 && l.rating < minRating) return false;
      if (q) {
        const ql = q.toLowerCase();
        const match = l.name.toLowerCase().includes(ql) ||
          l.oab.toLowerCase().includes(ql) ||
          l.city.toLowerCase().includes(ql) ||
          l.state.toLowerCase().includes(ql) ||
          l.specialty.toLowerCase().includes(ql);
        if (!match) return false;
      }
      return true;
    });
    list = [...list].sort((a, b) => {
      if (sort === "rating") return b.rating - a.rating;
      if (sort === "exp") return b.exp - a.exp;
      return a.name.localeCompare(b.name, "pt-BR");
    });
    return list;
  }, [ddd, spec, q, sort, minExp, minRating]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const displayed = aiMode ? aiRes : filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const cityLabel = ddd ? DDD_MAP[ddd] || `DDD ${ddd}` : "";
  const dddOptions = [...new Set(LAWYERS_DB.map(l => l.ddd))].sort((a, b) => Number(a) - Number(b));

  const hasActiveFilters = minExp > 0 || minRating > 0 || sort !== "rating";
  const filterCount = (minExp > 0 ? 1 : 0) + (minRating > 0 ? 1 : 0) + (sort !== "rating" ? 1 : 0);

  const handleFilter = (fn: () => void) => { fn(); resetPage(); };

  const runAI = async () => {
    setAiLd(true); setAiErr(""); setAiRes([]);
    const ctx = filtered.slice(0, 60).map(l =>
      `${l.name}|${l.oab}|${l.specialty}|${l.city}/${l.state}|DDD${l.ddd}|${l.exp}a|${l.rating}★`
    ).join("\n");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{
            role: "user",
            content: `Você é assistente jurídico especializado. Filtre e classifique os MELHORES advogados correspondentes${spec ? " de " + spec : ""}${ddd ? " no DDD " + ddd + " (" + cityLabel + ")" : " no Brasil"}. Priorize maior rating, mais experiência e especialidade relevante. Retorne APENAS um array JSON válido (sem markdown), com MÍNIMO 15 objetos contendo: id(int),name,oab,specialty,city,state,ddd,exp(int),rating(float entre 4.0 e 5.0),bio(string),phone(DDD+9 dígitos sem formatação),email,avatar(2 letras maiúsculas). DADOS:\n${ctx || "Sem filtro — use Brasil inteiro."}`
          }]
        })
      });
      const data = await res.json();
      const raw = data.content?.map((c: { text?: string }) => c.text || "").join("").replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(raw);
      setAiRes(parsed.map((l: Lawyer, i: number) => ({
        ...l, id: 9000 + i, profileUrl: "https://correspondentesnaweb.com.br", aiGenerated: true
      })));
    } catch {
      setAiErr("Erro no filtro IA. Exibindo resultados do banco.");
      setAiMode(false);
    }
    setAiLd(false);
  };

  const toggleAI = () => {
    const n = !aiMode;
    setAiMode(n);
    if (n) runAI(); else setAiRes([]);
  };

  const clearFilters = () => { setMinExp(0); setMinRating(0); setSort("rating"); resetPage(); };

  return (
    <div style={{ paddingTop: 64, paddingBottom: 92, minHeight: "100vh", position: "relative", zIndex: 1 }}>

      {/* Header */}
      <div style={{ padding: "18px 16px 0" }}>
        <div className="h1" style={{ fontSize: 22 }}>
          Encontre seu <span className="g-text">correspondente</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 5 }}>
          <span style={{ fontSize: 12.5, color: "var(--text2)", fontWeight: 600 }}>
            {aiMode ? aiRes.length : filtered.length} profissionais
            {ddd ? ` · DDD ${ddd} — ${cityLabel.split(" - ")[0]}` : ` · ${Object.keys(DDD_MAP).length} DDDs`}
          </span>
          {!aiMode && filtered.length > 0 && (
            <span className="badge b-green" style={{ fontSize: 9 }}>ONLINE</span>
          )}
        </div>
      </div>

      {/* DDD chips — scrollável */}
      <div style={{ padding: "12px 16px 0" }}>
        <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 10, scrollbarWidth: "none" }}>
          <button className={`chip ${!ddd ? "active" : ""}`} onClick={() => handleFilter(() => setDdd(""))}>🇧🇷 Todos</button>
          {QUICK_DDDS.map(d => (
            <button key={d} className={`chip ${ddd === d ? "active" : ""}`}
              onClick={() => handleFilter(() => setDdd(d === ddd ? "" : d))}>
              {d} · {DDD_MAP[d]?.split(" - ")[0]}
            </button>
          ))}
        </div>

        {/* Search + DDD select */}
        <div style={{ position: "relative", marginBottom: 8 }}>
          <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 15, pointerEvents: "none", color: "#5a5040" }}>🔍</span>
          <input
            className="inp"
            placeholder="Nome, OAB, cidade, estado ou especialidade..."
            value={q}
            onChange={e => handleFilter(() => setQ(e.target.value))}
            style={{ paddingLeft: 40, fontSize: 13 }}
            data-testid="input-search"
          />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 8 }}>
          <select className="inp" value={ddd} onChange={e => handleFilter(() => setDdd(e.target.value))} style={{ fontSize: 12 }} data-testid="select-ddd">
            <option value="">📍 Todos DDDs</option>
            {dddOptions.map(d => <option key={d} value={d}>{d} — {DDD_MAP[d] || d}</option>)}
          </select>
          <select className="inp" value={spec} onChange={e => handleFilter(() => setSpec(e.target.value))} style={{ fontSize: 12 }} data-testid="select-specialty">
            <option value="">⚖️ Especialidade</option>
            {SPECIALTIES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        {/* Filtros avançados toggle */}
        <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
          <button
            onClick={() => setShowFilters(f => !f)}
            style={{
              flex: 1, background: showFilters ? "rgba(212,175,55,0.1)" : "rgba(255,255,255,0.03)",
              border: `1px solid ${showFilters ? "rgba(212,175,55,0.35)" : "rgba(212,175,55,0.12)"}`,
              borderRadius: 13, padding: "10px 14px", cursor: "pointer",
              color: showFilters ? "#D4AF37" : "#b8a878", fontFamily: "inherit",
              fontWeight: 700, fontSize: 12, display: "flex", alignItems: "center",
              justifyContent: "center", gap: 6, transition: "all 0.2s",
            }}
          >
            ⚙️ Filtros avançados
            {filterCount > 0 && (
              <span style={{ background: "#D4AF37", color: "#080808", borderRadius: "50%", width: 18, height: 18, fontSize: 10, fontWeight: 900, display: "flex", alignItems: "center", justifyContent: "center" }}>
                {filterCount}
              </span>
            )}
          </button>
          {hasActiveFilters && (
            <button onClick={clearFilters} style={{
              background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)",
              borderRadius: 13, padding: "10px 14px", cursor: "pointer",
              color: "#f87171", fontFamily: "inherit", fontWeight: 700, fontSize: 12,
            }}>Limpar</button>
          )}
        </div>

        {/* Filtros avançados expandíveis */}
        {showFilters && (
          <div className="glass fade-up" style={{ borderRadius: 16, padding: 16, marginBottom: 8, border: "1px solid rgba(212,175,55,0.12)" }}>
            <div style={{ marginBottom: 14 }}>
              <div className="label" style={{ marginBottom: 8 }}>Ordenar por</div>
              <div style={{ display: "flex", gap: 6 }}>
                {([["rating", "⭐ Avaliação"], ["exp", "🏆 Experiência"], ["name", "🔤 Nome"]] as [SortKey, string][]).map(([k, label]) => (
                  <button key={k} onClick={() => handleFilter(() => setSort(k))} style={{
                    flex: 1, background: sort === k ? "rgba(212,175,55,0.15)" : "rgba(255,255,255,0.03)",
                    border: `1px solid ${sort === k ? "rgba(212,175,55,0.4)" : "rgba(212,175,55,0.1)"}`,
                    borderRadius: 10, padding: "8px 6px", cursor: "pointer",
                    color: sort === k ? "#D4AF37" : "#b8a878",
                    fontFamily: "inherit", fontWeight: 700, fontSize: 11, transition: "all 0.15s",
                  }}>{label}</button>
                ))}
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <div>
                <div className="label" style={{ marginBottom: 6 }}>Exp. mínima</div>
                <select className="inp" value={minExp} onChange={e => handleFilter(() => setMinExp(+e.target.value))} style={{ fontSize: 12, padding: "10px 12px" }}>
                  <option value={0}>Qualquer</option>
                  {[1, 2, 3, 5, 8, 10, 15].map(v => <option key={v} value={v}>{v}+ anos</option>)}
                </select>
              </div>
              <div>
                <div className="label" style={{ marginBottom: 6 }}>Avaliação mín.</div>
                <select className="inp" value={minRating} onChange={e => handleFilter(() => setMinRating(+e.target.value))} style={{ fontSize: 12, padding: "10px 12px" }}>
                  <option value={0}>Qualquer</option>
                  {[4.0, 4.2, 4.5, 4.7, 4.9].map(v => <option key={v} value={v}>{v}+★</option>)}
                </select>
              </div>
            </div>
          </div>
        )}

        {/* AI Box */}
        <div className={`glass ai-box ${aiMode ? "on" : ""}`} style={{ borderRadius: 15, padding: "13px 16px", marginBottom: 10, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ flex: 1, marginRight: 12 }}>
            <div style={{ fontSize: 13.5, fontWeight: 700, color: "var(--text)", display: "flex", alignItems: "center", gap: 7 }}>
              🧠 Filtro IA
              {aiMode && <span className="badge b-purple" style={{ fontSize: 9 }}>ATIVO</span>}
            </div>
            <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 2 }}>Claude analisa e ranqueia os melhores perfis</div>
          </div>
          <div className={`toggle ${aiMode ? "on" : ""}`} onClick={toggleAI} data-testid="toggle-ai">
            <div className="toggle-dot" />
          </div>
        </div>
      </div>

      {/* Loading AI */}
      {aiLd && (
        <div style={{ padding: "0 16px" }}>
          <div style={{ textAlign: "center", padding: "18px 0 12px", color: "#D4AF37", fontSize: 13.5, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", gap: 10 }}>
            <Spin /> Filtrando com IA…
          </div>
          {[0,1,2,3].map(i => <Skel key={i} />)}
        </div>
      )}

      {aiErr && <div style={{ padding: "0 16px 8px" }}><div className="alert a-err"><span>⚠️</span><span>{aiErr}</span></div></div>}

      {/* Results */}
      {!aiLd && (
        <div style={{ padding: "0 16px" }}>
          {displayed.length === 0 ? (
            <div style={{ textAlign: "center", padding: "64px 20px" }}>
              <div style={{ fontSize: 56 }}>🔍</div>
              <div className="h2" style={{ marginTop: 16, color: "var(--text2)" }}>Nenhum resultado</div>
              <div style={{ fontSize: 13, marginTop: 8, color: "var(--text3)" }}>Tente outro DDD ou remova os filtros</div>
              {hasActiveFilters && (
                <button onClick={clearFilters} className="btn btn-p" style={{ width: "auto", marginTop: 20, padding: "12px 24px" }}>Limpar filtros</button>
              )}
            </div>
          ) : (
            <>
              {aiMode && aiRes.length > 0 && (
                <div style={{ marginBottom: 10 }}>
                  <span className="badge b-purple">✨ {aiRes.length} resultados via Filtro IA (Claude)</span>
                </div>
              )}

              {!aiMode && (
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10, padding: "0 2px" }}>
                  <span style={{ fontSize: 11.5, color: "#5a5040", fontWeight: 600 }}>
                    {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)} de {filtered.length}
                  </span>
                  <span style={{ fontSize: 11, color: "#5a5040" }}>Página {page}/{totalPages}</span>
                </div>
              )}

              {displayed.map((l, i) => (
                <LCard key={l.id} l={l} isFav={favs.includes(l.id)} onFav={toggleFav} delay={Math.min(i * 20, 160)} />
              ))}

              {!aiMode && (
                <>
                  <Pagination page={page} total={filtered.length} onChange={p => { setPage(p); window.scrollTo({ top: 0, behavior: "smooth" }); }} />
                  <div style={{ textAlign: "center", padding: "8px 0 4px" }}>
                    <span style={{ fontSize: 10, color: "#333" }}>
                      correspondentesnaweb.com.br
                    </span>
                  </div>
                </>
              )}
            </>
          )}
        </div>
      )}

      <div style={{ textAlign: "center", padding: "14px 0 6px", opacity: 0.35 }}>
        <span className="gueto">By GUETO™</span>
      </div>
    </div>
  );
}
