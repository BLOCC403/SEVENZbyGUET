import { useState } from "react";
import { User, getUsers } from "@/lib/storage";
import { LAWYERS_DB, DDD_MAP } from "@/data/lawyers";
import { Spin } from "@/components/Spin";

const ADMIN_EMAIL = "/admin";
const ADMIN_PASS = "180703Bi";

interface Props {
  onLogin: (user: User) => void;
  onGoReg: () => void;
}

export function LoginScreen({ onLogin, onGoReg }: Props) {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [err, setErr] = useState("");
  const [ld, setLd] = useState(false);

  const go = async () => {
    setErr(""); setLd(true);
    await new Promise(r => setTimeout(r, 700));
    setLd(false);
    if (email === ADMIN_EMAIL && pass === ADMIN_PASS) {
      onLogin({ id: "admin", name: "Administrador", email: ADMIN_EMAIL, role: "admin", password: "", createdAt: new Date().toISOString() });
      return;
    }
    const u = getUsers().find(u => u.email === email && u.password === pass);
    if (!u) { setErr("Email ou senha incorretos."); return; }
    onLogin(u);
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "center", padding: "32px 20px", position: "relative", zIndex: 1 }}>
      <div style={{ maxWidth: 390, margin: "0 auto", width: "100%" }}>

        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 40 }} className="fade-up">
          <div style={{ display: "inline-flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
            <div style={{ position: "relative" }}>
              <div style={{
                width: 72, height: 72, borderRadius: 24,
                background: "linear-gradient(135deg, #D4AF37, #a07c10)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 30, boxShadow: "0 8px 32px rgba(212,175,55,0.35)",
              }}>⚖</div>
              <div style={{
                position: "absolute", top: -6, right: -8,
                background: "rgba(34,197,94,0.9)", borderRadius: 10,
                padding: "2px 7px", fontSize: 9, fontWeight: 900, color: "#fff",
                letterSpacing: 0.5, animation: "floatBadge 3s ease-in-out infinite",
              }}>v7</div>
            </div>
            <div>
              <div style={{
                fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 900,
                fontSize: 36, letterSpacing: -1, lineHeight: 1,
                background: "linear-gradient(135deg, #f5d97a, #D4AF37)",
                WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
              }}>SEVENZ</div>
              <div style={{ fontSize: 10, color: "#5a5040", letterSpacing: 3, fontWeight: 600, textTransform: "uppercase", marginTop: 5 }}>
                Rede Jurídica Nacional
              </div>
            </div>
          </div>

          {/* Stats */}
          <div style={{ display: "flex", alignItems: "center", gap: 6, justifyContent: "center", marginTop: 16, flexWrap: "wrap" }}>
            {[`${LAWYERS_DB.length.toLocaleString("pt-BR")}+ advogados`, `${Object.keys(DDD_MAP).length} DDDs`, "Brasil inteiro"].map((t, i) => (
              <span key={i} style={{
                background: "rgba(212,175,55,0.08)", border: "1px solid rgba(212,175,55,0.2)",
                borderRadius: 20, padding: "4px 11px", fontSize: 11, fontWeight: 700, color: "#D4AF37",
              }}>{t}</span>
            ))}
          </div>
        </div>

        {/* Card */}
        <div style={{ background: "#0e0e0e", border: "1px solid rgba(212,175,55,0.12)", borderRadius: 24, padding: 28 }} className="fade-up">
          <div className="label">Acesso à plataforma</div>
          <div className="h2" style={{ color: "var(--text)", marginBottom: 22, fontSize: 20 }}>Entrar na conta</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div>
              <div className="label">Email</div>
              <input className="inp" placeholder="seu@email.com" value={email}
                onChange={e => setEmail(e.target.value)} type="email" data-testid="input-email" />
            </div>
            <div>
              <div className="label">Senha</div>
              <input className="inp" placeholder="••••••••" value={pass}
                onChange={e => setPass(e.target.value)} type="password"
                onKeyDown={e => e.key === "Enter" && go()} data-testid="input-password" />
            </div>
            {err && (
              <div className="alert a-err">
                <span style={{ fontSize: 16, flexShrink: 0 }}>⚠️</span>
                <span>{err}</span>
              </div>
            )}
            <button className="btn btn-p" onClick={go} disabled={ld} style={{ marginTop: 6 }} data-testid="btn-login">
              {ld ? <Spin /> : <><span>Entrar</span><span style={{ fontSize: 18 }}>→</span></>}
            </button>
          </div>
        </div>

        <div style={{ textAlign: "center", marginTop: 20, fontSize: 14 }}>
          <span style={{ color: "var(--text3)" }}>Não tem conta? </span>
          <button onClick={onGoReg} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 14, fontWeight: 800 }} data-testid="btn-go-register">
            <span className="g-text">Criar conta grátis</span>
          </button>
        </div>
        <div style={{ textAlign: "center", padding: "18px 0 6px", opacity: 0.35 }}>
          <span className="gueto">By GUETO™</span>
        </div>
      </div>
    </div>
  );
}
