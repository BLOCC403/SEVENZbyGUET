export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: "user" | "admin";
  createdAt: string;
}

export interface Payment {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  status: "pending" | "pending_confirmation" | "paid";
  amount: number;
  createdAt: string;
  paidAt?: string;
}

export function getUsers(): User[] {
  try { return JSON.parse(localStorage.getItem("sev_users") || "[]"); } catch { return []; }
}
export function saveUsers(users: User[]): void {
  localStorage.setItem("sev_users", JSON.stringify(users));
}

export function getPayments(): Payment[] {
  try { return JSON.parse(localStorage.getItem("sev_pays") || "[]"); } catch { return []; }
}
export function savePayments(pays: Payment[]): void {
  localStorage.setItem("sev_pays", JSON.stringify(pays));
}

export function getFavs(userId: string): number[] {
  try { return JSON.parse(localStorage.getItem(`sev_favs_${userId}`) || "[]"); } catch { return []; }
}
export function saveFavs(userId: string, favs: number[]): void {
  localStorage.setItem(`sev_favs_${userId}`, JSON.stringify(favs));
}
