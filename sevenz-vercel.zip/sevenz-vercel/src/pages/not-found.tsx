export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#07080f]">
      <div className="text-center">
        <div className="text-6xl mb-4">⚖</div>
        <h1 className="text-2xl font-bold text-white mb-2">Página não encontrada</h1>
        <p className="text-gray-400">A página que você procura não existe.</p>
      </div>
    </div>
  );
}
