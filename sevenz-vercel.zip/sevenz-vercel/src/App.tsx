import { useState, useEffect } from "react";
import { User, getPayments } from "@/lib/storage";
import { LoginScreen } from "@/screens/LoginScreen";
import { RegisterScreen } from "@/screens/RegisterScreen";
import { PaymentScreen } from "@/screens/PaymentScreen";
import { SearchScreen } from "@/screens/SearchScreen";
import { FavoritesScreen } from "@/screens/FavoritesScreen";
import { AdminScreen } from "@/screens/AdminScreen";
import { ProfileScreen } from "@/screens/ProfileScreen";

type Screen = "login" | "register" | "payment" | "app";
type Tab = "search" | "favorites" | "admin" | "profile";

function NavBar({ activeTab, user, onTab }: { activeTab: Tab; user: User; onTab: (t: Tab) => void }) {
  const tabs: { id: Tab; icon: string; label: string; adminOnly?: boolean }[] = [
    { id: "search", icon: "🔍", label: "Buscar" },
    { id: "favorites", icon: "❤️", label: "Favoritos" },
    { id: "admin", icon: "🛡️", label: "Admin", adminOnly: true },
    { id: "profile", icon: "👤", label: "Perfil" },
  ];

  const visibleTabs = tabs.filter(t => !t.adminOnly || user.role === "admin");

  return (
    <>
      <div className="navbar">
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 20px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div className="g-bg" style={{ width: 32, height: 32, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>
              ⚖
            </div>
            <span className="h1" style={{ fontSize: 20 }}><span className="g-text">SEVENZ</span></span>
          </div>
          <span style={{ fontSize: 10, color: "var(--text3)", letterSpacing: 1.5, fontWeight: 600, textTransform: "uppercase" }}>
            Rede Jurídica Nacional
          </span>
        </div>
      </div>

      <div className="tabbar">
        <div style={{ display: "flex", justifyContent: "space-around", alignItems: "center" }}>
          {visibleTabs.map(t => (
            <button
              key={t.id}
              onClick={() => onTab(t.id)}
              data-testid={`tab-${t.id}`}
              style={{
                background: "none", border: "none", cursor: "pointer",
                display: "flex", flexDirection: "column", alignItems: "center", gap: 4,
                padding: "4px 16px", transition: "all 0.2s",
                flex: 1,
              }}
            >
              <span style={{ fontSize: 22, transition: "transform 0.25s cubic-bezier(0.34,1.56,0.64,1)", transform: activeTab === t.id ? "scale(1.2)" : "scale(1)" }}>
                {t.icon}
              </span>
              <span style={{ fontSize: 10, fontWeight: 700, color: activeTab === t.id ? "#7b97fa" : "var(--text3)", fontFamily: "'DM Sans', sans-serif", transition: "color 0.2s" }}>
                {t.label}
              </span>
              {activeTab === t.id && (
                <div style={{ width: 4, height: 4, borderRadius: "50%", background: "#4f6ef7" }} />
              )}
            </button>
          ))}
        </div>
      </div>
    </>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [user, setUser] = useState<User | null>(null);
  const [tab, setTab] = useState<Tab>("search");

  useEffect(() => {
    const saved = sessionStorage.getItem("sev_session");
    if (saved) {
      try {
        const u = JSON.parse(saved);
        const pays = getPayments();
        const myPay = pays.find((p) => p.userId === u.id);
        if (u.role === "admin" || myPay?.status === "paid") {
          setUser(u);
          setScreen("app");
        } else {
          setUser(u);
          setScreen("payment");
        }
      } catch {
        // invalid session
      }
    }
  }, []);

  const handleLogin = (u: User) => {
    sessionStorage.setItem("sev_session", JSON.stringify(u));
    setUser(u);
    const pays = getPayments();
    const myPay = pays.find((p) => p.userId === u.id);
    if (u.role === "admin" || myPay?.status === "paid") {
      setScreen("app");
    } else {
      setScreen("payment");
    }
  };

  const handleReg = (u: User) => {
    sessionStorage.setItem("sev_session", JSON.stringify(u));
    setUser(u);
    setScreen("payment");
  };

  const handleLogout = () => {
    sessionStorage.removeItem("sev_session");
    setUser(null);
    setScreen("login");
  };

  if (screen === "login") return <LoginScreen onLogin={handleLogin} onGoReg={() => setScreen("register")} />;
  if (screen === "register") return <RegisterScreen onReg={handleReg} onGoLogin={() => setScreen("login")} />;
  if (screen === "payment" && user) return <PaymentScreen user={user} onPaid={() => setScreen("app")} />;

  if (screen === "app" && user) {
    return (
      <div>
        <NavBar activeTab={tab} user={user} onTab={setTab} />
        {tab === "search" && <SearchScreen user={user} />}
        {tab === "favorites" && <FavoritesScreen user={user} />}
        {tab === "admin" && user.role === "admin" && <AdminScreen />}
        {tab === "profile" && <ProfileScreen user={user} onLogout={handleLogout} />}
      </div>
    );
  }

  return null;
}
